document.addEventListener('DOMContentLoaded', function () {
    const returnButton = document.getElementById('returnButton');

    returnButton.addEventListener('click', function () {
        window.location.href = '/HTML/MAINMENU.html';
    });
});
